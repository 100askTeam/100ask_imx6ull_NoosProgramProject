#ifndef   __COMMON_H__
#define   __COMMON_H__

#include "fsl_iomuxc.h"

#endif
