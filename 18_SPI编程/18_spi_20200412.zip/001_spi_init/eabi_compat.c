

int raise (int signum)
{
	return 0;
}

